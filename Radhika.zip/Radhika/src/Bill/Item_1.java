/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bill;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author AVENGERS
 */
@Entity
@Table(name = "ITEM", catalog = "", schema = "ROOT")
@NamedQueries({
    @NamedQuery(name = "Item_1.findAll", query = "SELECT i FROM Item_1 i")
    , @NamedQuery(name = "Item_1.findByItemcode", query = "SELECT i FROM Item_1 i WHERE i.itemPK.itemcode = :itemcode")
    , @NamedQuery(name = "Item_1.findByQuantity", query = "SELECT i FROM Item_1 i WHERE i.quantity = :quantity")
    , @NamedQuery(name = "Item_1.findByItemname", query = "SELECT i FROM Item_1 i WHERE i.itemPK.itemname = :itemname")
    , @NamedQuery(name = "Item_1.findByDistributor", query = "SELECT i FROM Item_1 i WHERE i.distributor = :distributor")
    , @NamedQuery(name = "Item_1.findByPrice", query = "SELECT i FROM Item_1 i WHERE i.price = :price")
    , @NamedQuery(name = "Item_1.findByGst", query = "SELECT i FROM Item_1 i WHERE i.gst = :gst")
    , @NamedQuery(name = "Item_1.findByTotal", query = "SELECT i FROM Item_1 i WHERE i.total = :total")
    , @NamedQuery(name = "Item_1.findByCompanyname", query = "SELECT i FROM Item_1 i WHERE i.companyname = :companyname")
    , @NamedQuery(name = "Item_1.findByMfg", query = "SELECT i FROM Item_1 i WHERE i.mfg = :mfg")
    , @NamedQuery(name = "Item_1.findByExpiary", query = "SELECT i FROM Item_1 i WHERE i.expiary = :expiary")})
public class Item_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ItemPK itemPK;
    @Basic(optional = false)
    @Column(name = "QUANTITY")
    private String quantity;
    @Basic(optional = false)
    @Column(name = "DISTRIBUTOR")
    private String distributor;
    @Basic(optional = false)
    @Column(name = "PRICE")
    private double price;
    @Basic(optional = false)
    @Column(name = "GST")
    private double gst;
    @Basic(optional = false)
    @Column(name = "TOTAL")
    private double total;
    @Basic(optional = false)
    @Column(name = "COMPANYNAME")
    private String companyname;
    @Basic(optional = false)
    @Column(name = "MFG")
    private String mfg;
    @Basic(optional = false)
    @Column(name = "EXPIARY")
    private String expiary;

    public Item_1() {
    }

    public Item_1(ItemPK itemPK) {
        this.itemPK = itemPK;
    }

    public Item_1(ItemPK itemPK, String quantity, String distributor, double price, double gst, double total, String companyname, String mfg, String expiary) {
        this.itemPK = itemPK;
        this.quantity = quantity;
        this.distributor = distributor;
        this.price = price;
        this.gst = gst;
        this.total = total;
        this.companyname = companyname;
        this.mfg = mfg;
        this.expiary = expiary;
    }

    public Item_1(String itemcode, String itemname) {
        this.itemPK = new ItemPK(itemcode, itemname);
    }

    public ItemPK getItemPK() {
        return itemPK;
    }

    public void setItemPK(ItemPK itemPK) {
        this.itemPK = itemPK;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        String oldQuantity = this.quantity;
        this.quantity = quantity;
        changeSupport.firePropertyChange("quantity", oldQuantity, quantity);
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        String oldDistributor = this.distributor;
        this.distributor = distributor;
        changeSupport.firePropertyChange("distributor", oldDistributor, distributor);
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        double oldPrice = this.price;
        this.price = price;
        changeSupport.firePropertyChange("price", oldPrice, price);
    }

    public double getGst() {
        return gst;
    }

    public void setGst(double gst) {
        double oldGst = this.gst;
        this.gst = gst;
        changeSupport.firePropertyChange("gst", oldGst, gst);
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        double oldTotal = this.total;
        this.total = total;
        changeSupport.firePropertyChange("total", oldTotal, total);
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        String oldCompanyname = this.companyname;
        this.companyname = companyname;
        changeSupport.firePropertyChange("companyname", oldCompanyname, companyname);
    }

    public String getMfg() {
        return mfg;
    }

    public void setMfg(String mfg) {
        String oldMfg = this.mfg;
        this.mfg = mfg;
        changeSupport.firePropertyChange("mfg", oldMfg, mfg);
    }

    public String getExpiary() {
        return expiary;
    }

    public void setExpiary(String expiary) {
        String oldExpiary = this.expiary;
        this.expiary = expiary;
        changeSupport.firePropertyChange("expiary", oldExpiary, expiary);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (itemPK != null ? itemPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Item_1)) {
            return false;
        }
        Item_1 other = (Item_1) object;
        if ((this.itemPK == null && other.itemPK != null) || (this.itemPK != null && !this.itemPK.equals(other.itemPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Bill.Item_1[ itemPK=" + itemPK + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
