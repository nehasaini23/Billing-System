package Bill;

import easyjavamail.JavaEmail;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class Signup extends javax.swing.JFrame {

    public Signup() {
        initComponents();
        ImageIcon img=new ImageIcon(getClass().getResource("/picture/backimg.jpg"));
        Image img1= img.getImage().getScaledInstance(bm.getHeight(),bm.getWidth(),Image.SCALE_SMOOTH);
        bm.setIcon(new ImageIcon(img1));
        ImageIcon img2=new ImageIcon(getClass().getResource("/picture/timg.jpg"));
        Image img3= img2.getImage().getScaledInstance(tt.getHeight(),tt.getWidth(),Image.SCALE_SMOOTH);
        tt.setIcon(new ImageIcon(img3));
       titlebar();
    }
void titlebar()
{
    this.setTitle("Signup");
            Image img2 = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/picture/timg.jpg"));
            this.setIconImage(img2);
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tt = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        re = new javax.swing.JTextField();
        na = new javax.swing.JTextField();
        em = new javax.swing.JTextField();
        pa = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        bm = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setLayout(null);
        jPanel1.add(tt);
        tt.setBounds(170, 0, 110, 100);

        jLabel1.setFont(new java.awt.Font("AvantGarde Md BT", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("SIGNUP");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(170, 100, 110, 40);

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("NAME :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 160, 140, 40);

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("EMAIL :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(30, 210, 140, 40);

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("PASSWORD :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(30, 260, 140, 40);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("REENTER PASSWORD :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(30, 310, 140, 40);
        jPanel1.add(re);
        re.setBounds(170, 310, 240, 40);
        jPanel1.add(na);
        na.setBounds(170, 160, 240, 40);
        jPanel1.add(em);
        em.setBounds(170, 210, 240, 40);
        jPanel1.add(pa);
        pa.setBounds(170, 260, 240, 40);

        jButton1.setText("SIGNUP");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(190, 370, 130, 40);
        jPanel1.add(bm);
        bm.setBounds(-10, 0, 450, 450);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 440, 440);

        setSize(new java.awt.Dimension(440, 466));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         String e,n,p,rp;
         e = em.getText();
         n = na.getText();
         p = pa.getText();
         rp = re.getText();
         int check=1;
        
           if(n.length()<=25 && !(n.isEmpty()))
            {
                check=1;
            } 
            else 
            {
                check=0;
                JOptionPane.showMessageDialog(rootPane, "Invalid Name ");
            }
            if( e.length()<=35 && e.contains("@") && !(e.isEmpty()))
            {
                check=1;
            } 
            else 
            {
                check=0;
                JOptionPane.showMessageDialog(rootPane, "Invalid Email ");
            }
          if(p.equals(rp) && !(p.isEmpty()) && p.length()<=20)
            {
                check=1;
            } 
            else 
            {
                check=0;
                JOptionPane.showMessageDialog(rootPane, "Invalid Password ");

            }
         
            if(check==1)
            {
        try {
            Connection c;
             c = DriverManager.getConnection("jdbc:derby://localhost:1527/Bill System", "root", "root");
            Statement s=c.createStatement();
            s.executeUpdate("insert into bsign values('"+e+"','"+n+"','"+p+"')");
            JOptionPane.showMessageDialog(rootPane, "Sucessfully Signup");
            
            JavaEmail sendemai=new JavaEmail();
            sendemai.setMailServerProperties();
            sendemai.createEmailMessage(em.getText(),"thanking you for registration with us","your email : "+e+"  and   password : "+p+" ");
            sendemai.sendEmail("nehasaini22213@gmail.com", "9414787796");    
            JOptionPane.showMessageDialog(rootPane, "mail sent sucessfully");
            
            this.dispose();
            Login lo = new Login();
            lo.setVisible(true);
            JOptionPane.showMessageDialog(rootPane, "Enter Register Email and Password");
        } catch (SQLException ex) {
            Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, null, ex);
        }    catch (MessagingException ex) {
                 Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, null, ex);
             }
        }
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Signup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bm;
    private javax.swing.JTextField em;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField na;
    private javax.swing.JTextField pa;
    private javax.swing.JTextField re;
    private javax.swing.JLabel tt;
    // End of variables declaration//GEN-END:variables
}
